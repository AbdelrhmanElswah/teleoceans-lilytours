<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddonsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'title' => 'required|min:2|max:100|string',
            'price' => 'required|min:1|max:100|string',
            'description' => 'string|min:6',
        ];
    }
}
