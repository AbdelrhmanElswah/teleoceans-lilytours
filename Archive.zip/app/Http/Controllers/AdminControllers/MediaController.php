<?php

namespace App\Http\Controllers\AdminControllers;

use App\Http\Controllers\Controller;
use App\Models\Media;
use App\Models\Program;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class MediaController extends Controller
{
    use GeneralTrait;

    protected $model;

    public function __construct(Media $model)
    {
        return $this->model = $model;
    }

    public function indexProgram()
    {
        $media = $this->model->get();
        $programs = Program::get();

        return view('admin.media.program', compact('media', 'programs'));
    }

    public function storeProgramMedia(Request $request)
    {
        $image = $this->ImageUpload($request, 'image', 'images/programs/media');
        $this->model->create($image + $request->all());

        return redirect()->route('media.program');
    }

    public function destroy($id)
    {
        $media = $this->model->findOrfail($id);
        unlink(public_path('images/programs/media'.$media->image));
        $media->delete();

        return redirect()->back();
    }
}
