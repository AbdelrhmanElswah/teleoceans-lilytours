<?php

namespace App\Http\Controllers;

use App\Models\Faq;
use App\Models\Program;
use Illuminate\Http\Request;

class HomePageController extends Controller
{
    public function index(){

        $programs = Program::inRandomOrder()->limit(6)->get();
        $news = Program::orderBy('id', 'DESC')->limit(4)->get();

        return view('Front.index',compact('programs','news'));
    }

    public function faqsPage(){
        $faqs = Faq::get();
        return view('Front.FAQ',compact('faqs'));
    }
}
