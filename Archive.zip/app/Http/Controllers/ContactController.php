<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Message;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index(){

        return view('Front.contact-us');
    }

    public function store(Request $request){

        Message::create($request->all());
        return redirect()->back()->with('success', 'Your message send successfully , We will call you soon');

    }
}
