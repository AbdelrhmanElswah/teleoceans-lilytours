<?php

namespace App\Traits;

trait GeneralTrait
{
    public function ImageUpload(\Illuminate\Http\Request $request, $name, $dir)
    {
        $file = $request->file($name);
        $filename = \Illuminate\Support\Str::random(40).'.'.$file->getClientOriginalExtension();
        $file->move(public_path($dir), $filename);
        $requestArray = [$name => $filename];

        return $requestArray;
    }
}
