


<div class="main-searchbar-wrapper">
    <div class="container">
        <div class="multi-main-searchber">
            <div class="main-searchbar-close search-toggle">
                <i class="bi bi-x-lg"></i>
            </div>
            <form action="#" method="post" id="main_searchbar">
                <div class="row g-4">
                    <div class="col-lg-10">
                        <div class="row gx-0 gy-4">
                            <div class="col-lg-3 col-md-6">
                                <div class="search-box-single destination-box">
                                    <div class="searchbox-icon ">
                                        <i class="bi bi-geo-alt"></i>
                                    </div>
                                    <div class="searchbox-input">
                                        <label for="deatination_drop">Destination</label>
                                        <select data-placeholder="Where Are You Going?" id="deatination_drop">
                                            <option value="">Where Are You Going?</option>
                                            <optgroup label="India">
                                                <option>
                                                    Solt Lake
                                                </option>
                                                <option>
                                                    Kolkata
                                                </option>
                                                <option>
                                                    Mohamia
                                                </option>
                                                <option>
                                                    Mumbai
                                                </option>
                                                <option>
                                                    New Delhi
                                                </option>
                                            </optgroup>
                                            <optgroup label=" Bangladash">
                                                <option>
                                                    Cox's Bazer
                                                </option>
                                                <option>
                                                    Rangamati
                                                </option>
                                                <option>
                                                    Banderban
                                                </option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="search-box-single type-box">
                                    <div class="searchbox-icon">
                                        <i class="bi bi-text-paragraph"></i>
                                    </div>
                                    <div class="searchbox-input">
                                        <label for="activity-dropdown">Travel Type</label>
                                        <select class="defult-select-drowpown" data-placeholder="All Activity"
                                                id="activity-dropdown">
                                            <option value="">All Activity</option>
                                            <option value="1">Type 1</option>
                                            <option value="2">Type 2</option>
                                            <option value="3">Type 3</option>
                                            <option value="4">Type 4</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="search-box-single type-box">
                                    <div class="searchbox-icon">
                                        <i class="bi bi-person-plus"></i>
                                    </div>
                                    <div class="searchbox-input">
                                        <label for="person-dropdown">Person</label>
                                        <select class="defult-select-drowpown" id="person-dropdown">
                                            <option selected value="0">01</option>
                                            <option value="1">02</option>
                                            <option value="2">03</option>
                                            <option value="3">04</option>
                                            <option value="4">05</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="search-box-single date-box">
                                    <div class="searchbox-icon">
                                        <i class="bi bi-capslock"></i>
                                    </div>
                                    <div class="searchbox-input date-picker-input">
                                        <label for="datepicker">When</label>
                                        <input placeholder="Select your date" type="text" name="checkIn" id="datepicker"
                                               value="" class="calendar">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="main-form-submit">
                            <button type="submit">Find Now</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="category-sidebar-wrapper">
    <div class="category-sidebar">
        <div class="category-header d-flex justify-content-between align-items-center">
            <h4>Category</h4>
            <div class="category-toggle">
                <i class="bi bi-x-lg"></i>
            </div>
        </div>
        <div class="row row-cols-lg-3 row-cols-2 gy-5 mt-3">
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate1.svg')}}" alt="">
                    </div>
                    <h5>Adventure</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate2.svg')}}" alt="">
                    </div>
                    <h5>Group Tour</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate3.svg')}}" alt="">
                    </div>
                    <h5>Couple Tour</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate4.svg')}}" alt="">
                    </div>
                    <h5>Single Tour</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate5.svg')}}" alt="">
                    </div>
                    <h5>Honeymoon</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate6.svg')}}" alt="">
                    </div>
                    <h5>Sea Beach</h5>
                </a>
            </div>
            <div class="col">
                <a class="category-box" href="package.html">
                    <div class="cate-icon mx-auto">
                        <img src="{{asset('assets/images/icons/cate7.svg')}}" alt="">
                    </div>
                    <h5>Mountain Tour</h5>
                </a>
            </div>
        </div>
    </div>
</div>


<div class="topbar-area topbar-style-one">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 align-items-center d-xl-flex d-none">
                <div class="topbar-contact-left">
                    <ul class="contact-list">
                        <li><i class="bi bi-telephone-fill"></i> <a href="tel:+17632275032">+1 763-227-5032</a></li>
                        <li><i class="bi bi-envelope-fill"></i> <a
                                href="https://demo.egenslab.com/cdn-cgi/l/email-protection#e1888f878ea18499808c918d84cf828e8c"><span
                                    class="__cf_email__" data-cfemail="325b5c545d72574a535f425e571c515d5f">[email&#160;protected]</span></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 text-xl-center text-md-start text-center">
                <div class="topbar-ad">
                    <a href="#">Black Friday Big Offer</a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 d-md-flex  d-none align-items-center justify-content-end">
                <ul class="topbar-social-links">
                    <li><a href="#"><i class='bx bxl-facebook'></i></a></li>
                    <li><a href="#"><i class='bx bxl-instagram-alt'></i></a></li>
                    <li><a href="#"><i class='bx bxl-twitter'></i></a></li>
                    <li><a href="#"><i class="bx bxl-whatsapp-square"></i></a></li>
                    <li><a href="#"><i class='bx bxl-pinterest'></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<header>
    <div class="header-area header-style-one">
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-lg-12 col-md-12 col-sm-12 col-xs-12 align-items-center d-xl-flex d-lg-block">
                    <div class="nav-logo d-flex justify-content-between align-items-center">
                        <a href="index.html"><img src="{{asset('assets/images/111.1.png')}}" style=" height: 90px" alt="logo"></a>
                        <div class="d-flex align-items-center gap-4">
                            <div class="nav-right d-xl-none">
                                <ul class="nav-actions">
                                    <li class="category-toggle">
                                        <i class='bx bx-category'></i>
                                    </li>
                                    <li class="search-toggle">
                                        <i class='bx bx-search-alt'></i>
                                    </li>
                                </ul>
                            </div>
                            <div class="mobile-menu d-flex ">
                                <a href="javascript:void(0)" class="hamburger d-block d-xl-none">
                                    <span class="h-top"></span>
                                    <span class="h-middle"></span>
                                    <span class="h-bottom"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-6 col-xs-6">
                    <nav class="main-nav float-end">
                        <div class="inner-logo d-xl-none text-center">
                            <a href="#"><img src="{{asset('assets/images/logo.png')}}" alt=""></a>
                        </div>
                        <ul>
                            <li class="has-child-menu">
                                <a href=index.html">Home</a>
                            </li>
                            <li><a href="about.html">Offers</a></li>
                            <li><a href="about.html">Tours</a></li>
                            <li><a href="about.html">Tailor Made</a></li>
                            <li class="has-child-menu">
                                <a href="javascript:void(0)">Others</a>
                                <i class="fl flaticon-plus">+</i>
                                <ul class="sub-menu">
                                    <li><a href="destination.html">About Us</a></li>
                                    <li><a href="destination-details.html">Contact Us</a></li>
                                    <li><a href="destination-details.html">Blog</a></li>
                                    <li><a href="destination-details.html">FAQ</a></li>

                                </ul>
                            </li>
                        </ul>
                        <div class="inner-contact-options d-xl-none">
                            <div class="contact-box-inner"><i class="bi bi-telephone-fill"></i> <a
                                    href="tel:+17632275032">+1 763-227-5032</a></div>
                            <div class="contact-box-inner"><i class="bi bi-envelope-fill"></i> <a
                                    href="https://demo.egenslab.com/cdn-cgi/l/email-protection#650c0b030a25001d04081509004b060a08"><span
                                        class="__cf_email__" data-cfemail="2841464e47684d50494558444d064b4745">[email&#160;protected]</span></a>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-xl-2">
                    <div class="nav-right float-end d-xl-flex d-none ">
                        <ul class="nav-actions">
                            <li class="category-toggle">
                                <i class='bx bx-category'></i>
                            </li>
                            <li class="search-toggle">
                                <i class='bx bx-search-alt'></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
